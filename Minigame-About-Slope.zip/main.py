import random
import replit


class player():
    def __init__(self, name, score):
        self.name = name
        self.score = score


slopeLogo = '''                                     
          88                                     
          88                                     
,adPPYbss 88  ,adPPYba,  8b,dPPYba,   ,adPPYba,  
I8[    ss 88 a8"     "8a 88P'    "8a a8P_____88  
 `"Y8ba,  88 8b       d8 88       d8 8PP"""""""  
aa    ]8I 88 "8a,   ,a8" 88b,   ,a8" "8b,   ,aa  
`"YbbdP"' 88  `"YbbdP"'  88`YbbdP"'   `"Ybbd8"'  
                         88                      
                         88  \n'''

print(slopeLogo)

questionA = " "
questionB = " "
slope = 0
yIntercept = 0
answer = " "
user_answer = " "
typeOfQuestions = 0

players = [
    player('LP', 0),
    player('AA', 0),
    player('ADA', 0),
    player('KB', 0),
    player('NCR', 0),
    player('JE', 0),
    player('HE', 0),
    player('RG', 0),
    player('KH', 0),
    player('JHH', 0),
    player('AK', 0),
    player('SM', 0),
    player('JN', 0),
    player('SO', 0),
    player('DP', 0),
    player('KP', 0),
    player('JP', 0),
    player('SR', 0),
    player('MS', 0),
    player('HS', 0),
    player('SS', 0),
    player('FV', 0),
    player('BZ', 0),
]


def generateQuestion():
    typeOfQuestion = random.randint(0, 5)
    print('\n')
    if typeOfQuestion == 0:
        slope = random.randint(-100, 100)
        yIntercept = random.randint(-100, 100)
        user_answer = str(
            input(
                f"Answer with \n Positive Slope (P), \n Negative Slope (N), \n Zero Slope (Z), \n Undefined Slope (U): \n \n y = {slope}x + {yIntercept}: "
            ))
        if slope >= 0:
            answer = "P"
        elif slope < 0:
            answer = "N"
    elif typeOfQuestion == 1:
        slope = random.randint(-100, 100)
        user_answer = str(
            input(
                f"\n Answer with \n Positive Slope (P), \n Negative Slope (N), \n Zero Slope (Z), \n Undefined Slope (U): \n \n x = {slope}: "
            ))
        answer = "U"
    elif typeOfQuestion == 2:
        listOfNum = [2, 4, 5, 10]
        n1 = random.randint(-100, 100)
        n2 = random.choice(listOfNum)
        n3 = n1 / n2
        user_answer = str(
            input(
                f"Answer with \n Positive Slope (P), \n Negative Slope (N), \n Zero Slope (Z), \n Undefined Slope (U): \n \n y = x({n1} - {n2}*{n3}): "
            ))
        answer = "Z"
    elif typeOfQuestion == 3:
        formatOfQuest = random.randint(1, 2)
        if formatOfQuest == 1:
            slope = random.randint(-100, 100)
            yIntercept = random.randint(-100, 100)
            xValue = random.randint(-100, 100)
            user_answer = str(
                input(
                    f"For a X value of {xValue}, what will the Y value be: y = {slope}x + {yIntercept}: "
                ))
            answer = str((slope * xValue) + yIntercept)
        elif formatOfQuest == 2:
            slope = random.randint(-100, 100)
            yIntercept = random.randint(-100, 100)
            xValue = random.randint(-100, 100)
            user_answer = str(
                input(
                    f"For a X value of {xValue}, what will the Y value be: y = {slope}x - y = {-1*yIntercept}: "
                ))
            answer = str((slope * xValue) + yIntercept)

    elif typeOfQuestion == 4:
        slope = random.randint(-100, 100)
        yIntercept = random.randint(-5, 5)
        user_answer = str(
            input(
                f"Is the following equation proportional(P) or non-proportional(NP) : {slope}x + {yIntercept}: "
            ))
        if yIntercept == 0:
            answer = "P"
        elif yIntercept != 0:
            answer = "NP"
    elif typeOfQuestion == 5:
        linearOrNot = random.randint(1, 2)
        if linearOrNot == 1:
            slope = random.randint(-100, 100)
            yIntercept = random.randint(-5, 5)
            user_answer = str(
                input(
                    f"Is the following equation linear(L) or non-linear(NL) : {slope}x + {yIntercept}: "
                ))
            answer = "L"
        elif linearOrNot == 2:
            slope = random.randint(-150, 150)
            square = random.randint(-150, 150)
            user_answer = str(
                input(
                    f"Is the following equation linear(L) or non-linear(NL) : {slope}x^{square}: "
                ))
            answer = "NL"

    if user_answer == answer:
        print("That is correct.")
        whoAnswer = str(input("Who answered the question: "))
        for student in players:
            if student.name.lower() == whoAnswer.lower():
                student.score += 1
    elif user_answer != answer:
        print("Incorrect")
        print(f"The correct answer is {answer}")


MenuChoice = str(
    input("\n Play (P), Learn (L), or Learn about the game (LG): "))

while (True):
    if MenuChoice.lower() == "p":
        replit.clear()
        print(slopeLogo)
        howManyQuestions = int(input("How many questions should there be? "))

        for i in range(howManyQuestions):
            generateQuestion()

        firstPlayer = None
        secondPlayer = None
        thirdPlayer = None

        for student in players:
            if student.score > 0:
                if firstPlayer == None:
                    firstPlayer = student
                elif secondPlayer == None:
                    if student.score > firstPlayer.score:
                        secondPlayer = firstPlayer
                        firstPlayer = student
                    else:
                        secondPlayer = student
                elif thirdPlayer == None:
                    if student.score > firstPlayer.score:
                        thirdPlayer = secondPlayer
                        secondPlayer = firstPlayer
                        firstPlayer = student
                    elif student.score > secondPlayer.score:
                        thirdPlayer = secondPlayer
                        secondPlayer = student
                    else:
                        thirdPlayer = student
                else:
                    if student.score > firstPlayer.score:
                        thirdPlayer = secondPlayer
                        secondPlayer = firstPlayer
                        firstPlayer = student
                    elif student.score > secondPlayer.score:
                        thirdPlayer = secondPlayer
                        secondPlayer = student
                    elif student.score > thirdPlayer.score:
                        thirdPlayer = student
        replit.clear
        print('The winners are...\n')

        if firstPlayer != None:
            print('1.', firstPlayer.name, '-', firstPlayer.score, '\n')

        if secondPlayer != None:
            print('2.', secondPlayer.name, '_', secondPlayer.score, '\n')

        if thirdPlayer != None:
            print('3.', thirdPlayer.name, '_', thirdPlayer.score, '\n')

        print('Game Over.....')
        input("Press Space and Enter to return to return to the menu. ")
        replit.clear()

        for player in players:
            player.score = 0

        print(slopeLogo)
        MenuChoice = str(
            input("\n Play (P), Learn (L), or Learn about the game (LG): "))
    elif MenuChoice.lower() == "l":
        replit.clear()
        print(slopeLogo)
        print(
            "\n A line with a positive slope, has a increase in the Y-value, for every increase in the X-value. It, as the name suggests, has a positive slope. \n \n A line with a negative slope, has a decrease in the Y-value, for each increase in the X-value. It, as the name suggests, has a negative slope. \n \n A line with a zero slope has no change in the Y-value, for each change in the X-value. It, as the name suggests, has a slope of zero. \n \n A line with an undefined slope has a constant X-value and a constantly changing Y-value. It cannot be written in the Slope-Intercept form. It,as the name suggests, has an undefined slope. \n \n"
        )
        goBack = str(
            input("Press Space and Enter to return to return to the menu. "))
        replit.clear()
        print(slopeLogo)
        MenuChoice = str(
            input("\n Play (P), Learn (L), or Learn about the game (LG): "))
    elif MenuChoice == "LG":
        replit.clear()
        print(
            "The game is a text based mini-quiz. It completely randomly generates a question, from four different types of questions. \n The questions can be about finding what kind of slope a certain equation has, finding the y-value for a certain x-value in an equation, finding if the equation is proportional or not, or finding if the equation is linear."
        )
        goBack = str(
            input("Press Space and Enter to return to return to the menu. "))
        replit.clear()
        print(slopeLogo)
        MenuChoice = str(
            input("\n Play (P), Learn (L), or Learn about the game (LG): "))
